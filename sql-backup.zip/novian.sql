--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: status; Type: TYPE; Schema: public; Owner: fleetimee
--

CREATE TYPE public.status AS ENUM (
    '0051',
    '0052',
    '0053'
);


ALTER TYPE public.status OWNER TO fleetimee;

--
-- Name: statusvalue; Type: TYPE; Schema: public; Owner: fleetimee
--

CREATE TYPE public.statusvalue AS ENUM (
    '0051',
    '0052',
    '0053'
);


ALTER TYPE public.statusvalue OWNER TO fleetimee;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: answers; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.answers (
    id_answer bigint NOT NULL,
    id_question bigint,
    answer_text text,
    is_correct boolean
);


ALTER TABLE public.answers OWNER TO fleetimee;

--
-- Name: answers_id_answer_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.answers_id_answer_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.answers_id_answer_seq OWNER TO fleetimee;

--
-- Name: answers_id_answer_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.answers_id_answer_seq OWNED BY public.answers.id_answer;


--
-- Name: approval_course; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.approval_course (
    id_approval_course integer NOT NULL,
    user_uuid_approver uuid,
    id_course integer NOT NULL,
    comment text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    user_uuid_request uuid,
    approved_at timestamp with time zone,
    status public.statusvalue DEFAULT '0051'::public.statusvalue
);


ALTER TABLE public.approval_course OWNER TO fleetimee;

--
-- Name: approval_course_id_approval_course_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.approval_course_id_approval_course_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.approval_course_id_approval_course_seq OWNER TO fleetimee;

--
-- Name: approval_course_id_approval_course_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.approval_course_id_approval_course_seq OWNED BY public.approval_course.id_approval_course;


--
-- Name: approval_knowledge; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.approval_knowledge (
    id_approval_knowledge integer NOT NULL,
    user_uuid_approver uuid,
    id_knowledge integer NOT NULL,
    status public.statusvalue DEFAULT '0051'::public.statusvalue,
    comment text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    user_uuid_request uuid,
    approved_at timestamp with time zone
);


ALTER TABLE public.approval_knowledge OWNER TO fleetimee;

--
-- Name: approval_knowledge_id_approval_knowledge_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.approval_knowledge_id_approval_knowledge_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.approval_knowledge_id_approval_knowledge_seq OWNER TO fleetimee;

--
-- Name: approval_knowledge_id_approval_knowledge_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.approval_knowledge_id_approval_knowledge_seq OWNED BY public.approval_knowledge.id_approval_knowledge;


--
-- Name: category; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.category (
    id_category bigint NOT NULL,
    category_name text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    image text DEFAULT 'https://placehold.co/1280x720'::text,
    total_knowledge bigint
);


ALTER TABLE public.category OWNER TO fleetimee;

--
-- Name: category_id_category_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.category_id_category_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.category_id_category_seq OWNER TO fleetimee;

--
-- Name: category_id_category_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.category_id_category_seq OWNED BY public.category.id_category;


--
-- Name: contents; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.contents (
    id_content bigint NOT NULL,
    content_title text,
    content_type text,
    image text,
    link text,
    id_section bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.contents OWNER TO fleetimee;

--
-- Name: contents_id_content_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.contents_id_content_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contents_id_content_seq OWNER TO fleetimee;

--
-- Name: contents_id_content_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.contents_id_content_seq OWNED BY public.contents.id_content;


--
-- Name: courses; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.courses (
    id_course bigint NOT NULL,
    id_knowledge bigint,
    course_name text,
    course_desc text,
    image text DEFAULT 'https://placehold.co/1280x720'::text,
    date_start timestamp with time zone,
    date_end timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.courses OWNER TO fleetimee;

--
-- Name: courses_id_course_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.courses_id_course_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.courses_id_course_seq OWNER TO fleetimee;

--
-- Name: courses_id_course_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.courses_id_course_seq OWNED BY public.courses.id_course;


--
-- Name: knowledges; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.knowledges (
    id_knowledge bigint NOT NULL,
    knowledge_title text,
    description text,
    status text DEFAULT '0032'::text,
    image text DEFAULT 'https://placehold.co/1280x720'::text,
    id_category bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.knowledges OWNER TO fleetimee;

--
-- Name: knowledges_id_knowledge_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.knowledges_id_knowledge_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledges_id_knowledge_seq OWNER TO fleetimee;

--
-- Name: knowledges_id_knowledge_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.knowledges_id_knowledge_seq OWNED BY public.knowledges.id_knowledge;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.posts (
    id_post integer NOT NULL,
    id_threads integer NOT NULL,
    user_uuid uuid NOT NULL,
    content text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.posts OWNER TO fleetimee;

--
-- Name: posts_id_post_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.posts_id_post_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_id_post_seq OWNER TO fleetimee;

--
-- Name: posts_id_post_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.posts_id_post_seq OWNED BY public.posts.id_post;


--
-- Name: questions; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.questions (
    id_question bigint NOT NULL,
    id_quiz bigint,
    question_text text
);


ALTER TABLE public.questions OWNER TO fleetimee;

--
-- Name: questions_id_question_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.questions_id_question_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.questions_id_question_seq OWNER TO fleetimee;

--
-- Name: questions_id_question_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.questions_id_question_seq OWNED BY public.questions.id_question;


--
-- Name: quizzes; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.quizzes (
    id_quiz bigint NOT NULL,
    quiz_title text,
    quiz_desc text,
    quiz_type text,
    created_at timestamp with time zone,
    id_section bigint,
    status_text text
);


ALTER TABLE public.quizzes OWNER TO fleetimee;

--
-- Name: quizzes_id_quiz_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.quizzes_id_quiz_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quizzes_id_quiz_seq OWNER TO fleetimee;

--
-- Name: quizzes_id_quiz_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.quizzes_id_quiz_seq OWNED BY public.quizzes.id_quiz;


--
-- Name: references; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public."references" (
    id_ref bigint NOT NULL,
    code_ref1 text NOT NULL,
    value_ref1 character varying NOT NULL,
    code_ref2 character varying
);


ALTER TABLE public."references" OWNER TO fleetimee;

--
-- Name: COLUMN "references".id_ref; Type: COMMENT; Schema: public; Owner: fleetimee
--

COMMENT ON COLUMN public."references".id_ref IS 'increment';


--
-- Name: references_id_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.references_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.references_id_seq OWNER TO fleetimee;

--
-- Name: references_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.references_id_seq OWNED BY public."references".id_ref;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.roles (
    id_role bigint NOT NULL,
    role_name text,
    role_description text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.roles OWNER TO fleetimee;

--
-- Name: roles_id_role_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.roles_id_role_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_role_seq OWNER TO fleetimee;

--
-- Name: roles_id_role_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.roles_id_role_seq OWNED BY public.roles.id_role;


--
-- Name: section_course; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.section_course (
    course_id_course bigint NOT NULL,
    section_id_section bigint NOT NULL
);


ALTER TABLE public.section_course OWNER TO fleetimee;

--
-- Name: section_knowledge; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.section_knowledge (
    section_id_section bigint NOT NULL,
    knowledge_id_knowledge bigint NOT NULL
);


ALTER TABLE public.section_knowledge OWNER TO fleetimee;

--
-- Name: sections; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.sections (
    id_section bigint NOT NULL,
    section_title text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.sections OWNER TO fleetimee;

--
-- Name: sections_id_section_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.sections_id_section_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sections_id_section_seq OWNER TO fleetimee;

--
-- Name: sections_id_section_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.sections_id_section_seq OWNED BY public.sections.id_section;


--
-- Name: threads; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.threads (
    id_threads integer NOT NULL,
    id_course bigint NOT NULL,
    threads_title character varying NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.threads OWNER TO fleetimee;

--
-- Name: threads_id_threads_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.threads_id_threads_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.threads_id_threads_seq OWNER TO fleetimee;

--
-- Name: threads_id_threads_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.threads_id_threads_seq OWNED BY public.threads.id_threads;


--
-- Name: user_course; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.user_course (
    course_id_course bigint NOT NULL,
    user_uuid uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.user_course OWNER TO fleetimee;

--
-- Name: user_fav_knowledge; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.user_fav_knowledge (
    users_uuid integer
);


ALTER TABLE public.user_fav_knowledge OWNER TO fleetimee;

--
-- Name: user_quizzes; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.user_quizzes (
    id_user_quiz bigint NOT NULL,
    user_uuid uuid,
    id_quiz bigint NOT NULL,
    score bigint NOT NULL,
    selected_answers jsonb
);


ALTER TABLE public.user_quizzes OWNER TO fleetimee;

--
-- Name: user_quizzes_id_user_quiz_seq; Type: SEQUENCE; Schema: public; Owner: fleetimee
--

CREATE SEQUENCE public.user_quizzes_id_user_quiz_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_quizzes_id_user_quiz_seq OWNER TO fleetimee;

--
-- Name: user_quizzes_id_user_quiz_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fleetimee
--

ALTER SEQUENCE public.user_quizzes_id_user_quiz_seq OWNED BY public.user_quizzes.id_user_quiz;


--
-- Name: user_role; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.user_role (
    role_id_role bigint NOT NULL,
    user_uuid uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.user_role OWNER TO fleetimee;

--
-- Name: users; Type: TABLE; Schema: public; Owner: fleetimee
--

CREATE TABLE public.users (
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    username text,
    email text,
    password text,
    last_login timestamp with time zone
);


ALTER TABLE public.users OWNER TO fleetimee;

--
-- Name: answers id_answer; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.answers ALTER COLUMN id_answer SET DEFAULT nextval('public.answers_id_answer_seq'::regclass);


--
-- Name: approval_course id_approval_course; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_course ALTER COLUMN id_approval_course SET DEFAULT nextval('public.approval_course_id_approval_course_seq'::regclass);


--
-- Name: approval_knowledge id_approval_knowledge; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_knowledge ALTER COLUMN id_approval_knowledge SET DEFAULT nextval('public.approval_knowledge_id_approval_knowledge_seq'::regclass);


--
-- Name: category id_category; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.category ALTER COLUMN id_category SET DEFAULT nextval('public.category_id_category_seq'::regclass);


--
-- Name: contents id_content; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.contents ALTER COLUMN id_content SET DEFAULT nextval('public.contents_id_content_seq'::regclass);


--
-- Name: courses id_course; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.courses ALTER COLUMN id_course SET DEFAULT nextval('public.courses_id_course_seq'::regclass);


--
-- Name: knowledges id_knowledge; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.knowledges ALTER COLUMN id_knowledge SET DEFAULT nextval('public.knowledges_id_knowledge_seq'::regclass);


--
-- Name: posts id_post; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.posts ALTER COLUMN id_post SET DEFAULT nextval('public.posts_id_post_seq'::regclass);


--
-- Name: questions id_question; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.questions ALTER COLUMN id_question SET DEFAULT nextval('public.questions_id_question_seq'::regclass);


--
-- Name: quizzes id_quiz; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.quizzes ALTER COLUMN id_quiz SET DEFAULT nextval('public.quizzes_id_quiz_seq'::regclass);


--
-- Name: references id_ref; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public."references" ALTER COLUMN id_ref SET DEFAULT nextval('public.references_id_seq'::regclass);


--
-- Name: roles id_role; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.roles ALTER COLUMN id_role SET DEFAULT nextval('public.roles_id_role_seq'::regclass);


--
-- Name: sections id_section; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.sections ALTER COLUMN id_section SET DEFAULT nextval('public.sections_id_section_seq'::regclass);


--
-- Name: threads id_threads; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.threads ALTER COLUMN id_threads SET DEFAULT nextval('public.threads_id_threads_seq'::regclass);


--
-- Name: user_quizzes id_user_quiz; Type: DEFAULT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.user_quizzes ALTER COLUMN id_user_quiz SET DEFAULT nextval('public.user_quizzes_id_user_quiz_seq'::regclass);


--
-- Data for Name: answers; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.answers (id_answer, id_question, answer_text, is_correct) FROM stdin;
1	1	10	f
2	1	15	f
3	1	17	t
4	1	25	f
5	2	Integer	f
6	2	String	t
7	2	Boolean	f
8	2	Float	f
9	3	my_list = []	t
10	3	my_list = {}	f
11	3	my_list = [0]	f
12	3	my_list = None	f
13	4	HyperText Markup Language	t
14	4	Hyperlink and Text Markup Language	f
15	4	Highly Typed Markdown Language	f
16	4	Hypertext Transfer Markup Language	f
17	5	Menyimpan data	f
18	5	Mengatur tampilan dan gaya dari elemen-elemen HTML	t
19	5	Menyediakan layanan database	f
20	5	Menggunakan JavaScript	f
21	6	<div> adalah untuk gambar, <span> adalah untuk teks	f
22	6	<div> digunakan untuk teks, <span> digunakan untuk gambar	f
23	6	<div> digunakan untuk membuat blok elemen, <span> digunakan untuk membuat inline elemen.	t
24	6	<div> digunakan untuk membuat inline elemen, <span> digunakan untuk membuat blok elemen.	f
25	7	Tes Jawabban	f
26	7	Jawaban bener	t
27	7	Tes Jawaban 2	f
28	7	Tes Jawaban 3	f
29	8	Recrate	t
30	8	adad	f
31	8	adasdads	f
32	9	Sebuah spesies beruang	f
33	9	Sebuah pustaka Python untuk analisis data	t
34	9	Sebuah kota di Jepang	f
35	9	Sebuah jenis kue	f
36	10	Mengolah gambar	f
37	10	Menghitung angka Fibonacci	f
38	10	Mengelola data tabular	t
39	10	Membuat aplikasi mobile	f
40	11	pd.load_csv()	f
41	11	 pd.read_csv()	t
42	11	pd.open_csv()	f
43	11	pd.read_excel()	f
44	12	Mengubah tampilan DataFrame menjadi tabel HTML	f
45	12	Menghapus beberapa baris pertama dari DataFrame	f
46	12	Menampilkan beberapa baris pertama dari DataFrame	t
47	12	Menghitung jumlah baris dalam DataFrame	f
48	13	Tidak ada perbedaan, keduanya sama	f
49	13	Series adalah satu dimensi, DataFrame adalah dua dimensi	t
50	13	 Series hanya berisi data numerik, DataFrame bisa berisi teks	f
51	13	DataFrame hanya digunakan untuk visualisasi data	f
52	14	Angka yang menunjukkan urutan baris	t
53	14	Nama kolom dalam DataFrame	f
54	14	Tanda baca khusus yang digunakan dalam teks	f
55	14	Tidak ada yang dimaksud dengan 'index' dalam Pandas	f
56	15	Tidak ada perbedaan, keduanya sama	f
57	15	loc[] mengakses data berdasarkan label, iloc[] mengakses data berdasarkan posisi	t
58	15	loc[] hanya digunakan untuk mengubah data, iloc[] hanya digunakan untuk melihat data	f
59	15	loc[] digunakan untuk mengakses data numerik, iloc[] untuk data teks	f
60	16	Menggunakan metode .delete()	f
61	16	Menggunakan metode .remove()	f
62	16	Menggunakan metode .drop()	t
63	16	Tidak mungkin menghapus kolom dalam DataFrame	f
64	17	Mengganti nama kolom dalam DataFrame	f
65	17	Menampilkan ringkasan statistik dari DataFrame	t
66	17	Menghapus data yang tidak valid	f
67	17	Menambahkan data baru ke dalam DataFrame	f
68	18	Menggunakan metode .rename()	t
69	18	Menggunakan metode .replace()	f
70	18	Menggunakan metode .edit_column()	f
71	18	Tidak mungkin mengganti nama kolom dalam DataFrame	f
72	19	Mengelompokkan data berdasarkan jenis kelamin	f
73	19	Menggabungkan dua DataFrame	f
74	19	Mengurutkan data berdasarkan kolom tertentu	f
75	19	Mengelompokkan data berdasarkan kriteria tertentu untuk analisis lebih lanjut	t
76	20	Tes Jawabban	f
77	20	Jawaban bener	f
78	20	Highly Typed Markdown Language	f
79	20	Tes Jawaban 3	t
80	21	10	t
81	21	15	f
82	21	Tes Jawaban 2	f
83	21	Sebuah jenis kue	f
84	22	Santoso Rohmad	t
85	22	Naruto	f
86	22	Madara	f
87	22	Zoro	f
\.


--
-- Data for Name: approval_course; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.approval_course (id_approval_course, user_uuid_approver, id_course, comment, created_at, updated_at, user_uuid_request, approved_at, status) FROM stdin;
5	58d76fc2-db09-491a-8387-f2a5750b64e3	4	Gorengan	2023-09-25 08:55:31.779+00	2023-09-25 08:55:33.604+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-10-18 03:33:15.647+00	0052
4	58d76fc2-db09-491a-8387-f2a5750b64e3	3	ghgg	2023-09-24 12:22:48.395+00	2023-09-24 12:22:49.681+00	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	2023-10-18 03:34:15.644+00	0052
7	58d76fc2-db09-491a-8387-f2a5750b64e3	5	Udah lah bang	2023-11-02 08:30:56.167372+00	2023-11-02 08:30:56.167372+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-11-02 08:32:18.401+00	0051
1	58d76fc2-db09-491a-8387-f2a5750b64e3	1	OKedeh	2023-09-23 11:58:09.329+00	2023-09-23 11:58:06.819+00	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	2023-11-06 03:21:04.45+00	0052
2	58d76fc2-db09-491a-8387-f2a5750b64e3	2	OKe deh	2023-09-23 18:48:01.493+00	2023-09-23 18:48:03.19+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-11-06 03:21:13.104+00	0052
8	58d76fc2-db09-491a-8387-f2a5750b64e3	7	Yaudah	2023-11-06 01:58:15.723946+00	2023-11-06 01:58:15.723946+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-11-06 04:34:23.032+00	0052
\.


--
-- Data for Name: approval_knowledge; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.approval_knowledge (id_approval_knowledge, user_uuid_approver, id_knowledge, status, comment, created_at, updated_at, user_uuid_request, approved_at) FROM stdin;
10	58d76fc2-db09-491a-8387-f2a5750b64e3	12	0052	Oke bgt	2023-09-26 08:26:46.77+00	2023-09-26 08:26:50.935+00	b3b9b16c-490f-4b02-9ab6-f7cca037f08b	2023-09-26 08:27:06.81+00
11	58d76fc2-db09-491a-8387-f2a5750b64e3	13	0052	Kita gaskeun	2023-09-26 08:38:09.981+00	2023-09-26 08:38:14.139+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-11-01 06:20:44.243+00
7	58d76fc2-db09-491a-8387-f2a5750b64e3	5	0052	Sudah oke	2023-09-26 08:24:30.992+00	2023-09-26 08:24:33.45+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-11-03 09:06:17.787+00
12	58d76fc2-db09-491a-8387-f2a5750b64e3	14	0052	Sudah oke	2023-09-26 08:44:52.05+00	2023-09-26 08:44:53.962+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-11-03 09:06:38.708+00
27	\N	23	0051	Iyadeh\n	2023-11-06 05:56:17.413869+00	2023-11-06 05:56:17.413869+00	b3b9b16c-490f-4b02-9ab6-f7cca037f08b	\N
1	58d76fc2-db09-491a-8387-f2a5750b64e3	1	0052	Oke deh	2023-09-06 22:18:33.859+00	2023-09-26 08:07:55.948985+00	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	2023-09-27 05:44:05.104+00
2	58d76fc2-db09-491a-8387-f2a5750b64e3	2	0052		2023-09-15 08:13:38.58+00	2023-09-26 08:13:41.75+00	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	2023-09-15 23:10:35.901+00
5	58d76fc2-db09-491a-8387-f2a5750b64e3	3	0052	dgdg	2023-09-26 08:20:17.207+00	2023-09-26 08:20:19.189+00	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	2023-09-27 03:04:10.298+00
9	58d76fc2-db09-491a-8387-f2a5750b64e3	7	0052	NIgga	2023-09-26 08:26:29.084+00	2023-09-26 08:26:30.932+00	b3b9b16c-490f-4b02-9ab6-f7cca037f08b	2023-09-27 03:04:52.748+00
26	dfdd8512-d688-47af-bcfc-7e1f676a651c	22	0051	Tessss	2023-11-01 06:21:46.0537+00	2023-11-01 06:21:46.0537+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-11-06 09:56:31.13+00
6	58d76fc2-db09-491a-8387-f2a5750b64e3	4	0052	Oke	2023-09-26 08:22:21.248+00	2023-09-26 08:22:23.847+00	b3b9b16c-490f-4b02-9ab6-f7cca037f08b	2023-09-28 17:00:52.013+00
8	58d76fc2-db09-491a-8387-f2a5750b64e3	6	0052	jhjh	2023-09-26 08:24:48.246+00	2023-09-26 08:24:52.911+00	b3b9b16c-490f-4b02-9ab6-f7cca037f08b	2023-09-14 17:00:00+00
18	58d76fc2-db09-491a-8387-f2a5750b64e3	15	0052		2023-10-31 06:57:53.391747+00	2023-10-31 06:57:53.392719+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-10-31 09:17:20.838+00
25	58d76fc2-db09-491a-8387-f2a5750b64e3	21	0052	Tidak OKe ini masih busuk	2023-11-01 01:20:50.115595+00	2023-11-01 01:20:50.115595+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-11-01 02:17:53.917+00
24	58d76fc2-db09-491a-8387-f2a5750b64e3	16	0053	Terima kasih, tapi aku nggak butuh.	2023-10-31 12:40:48.137932+00	2023-10-31 12:40:48.137932+00	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-11-01 02:18:30.246+00
\.


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.category (id_category, category_name, created_at, updated_at, image, total_knowledge) FROM stdin;
10	Ruby	2023-08-22 09:59:59.986554+00	2023-08-22 09:59:59.986554+00	https://th.bing.com/th/id/R.63dad4ba0659d3c3faff44fac3b2ca4a?rik=XpFK80yXlcKV3w&riu=http%3a%2f%2fcodecondo.com%2fwp-content%2fuploads%2f2017%2f09%2fRuby-Programming.jpg&ehk=QSikqtmRMSntbmbMIlbhpgZ3tpdONMBD7hN2tvEA9Jk%3d&risl=&pid=ImgRaw&r=0&sres=1&sresct=1	\N
7	React	2023-08-22 09:59:59.986554+00	2023-08-22 09:59:59.986554+00	https://th.bing.com/th/id/OIP.y6C4nSvy2Woe0m7bWEn4BAHaD4?pid=ImgDet&rs=1	\N
9	Python	2023-08-22 09:59:59.986554+00	2023-08-22 09:59:59.986554+00	https://monkfox.com/wp-content/uploads/2016/02/maxresdefault.jpg	\N
8	Typescript	2023-08-22 09:59:59.986554+00	2023-08-23 02:14:23.423237+00	https://www.positronx.io/wp-content/uploads/2018/11/positronx-banner-1152-1.jpg	\N
13	Golang	2023-08-23 03:53:31.139061+00	2023-08-23 03:53:31.139061+00	https://miro.medium.com/max/3152/0*7vQ8eRc28yz9k__r.png	\N
11	Javascript	2023-08-23 03:51:53.757041+00	2023-08-23 03:51:53.757041+00	https://i0.wp.com/www.techomoro.com/wp-content/uploads/2019/11/javascript-736400-1.png?fit=1854%2C941&ssl=1	\N
25	PHP	2023-08-28 04:39:33.055879+00	2023-08-28 04:39:33.055879+00	https://1.bp.blogspot.com/-gxoMTZdNRdI/UcekDGVFqSI/AAAAAAAAAOw/YCWxwoY27C4/s1600/php-programming-language.jpg	\N
12	Rust	2023-08-23 03:53:26.306836+00	2023-08-23 03:53:26.306836+00	https://www.clipartkey.com/mpngs/m/194-1949306_hax0rferriswithkey-rust-programming-language-logo.png	\N
14	Kotlin	2023-08-23 03:54:28.781222+00	2023-08-23 03:54:28.781222+00	https://fossbytes.com/wp-content/uploads/2017/05/kotlin-android-learn.png	\N
17	Java	2023-08-23 03:54:52.517322+00	2023-08-23 07:13:00.546541+00	https://fossbytes.com/wp-content/uploads/2017/09/Why-is-Java-the-best-programming-Language.png	\N
18	Unity	2023-08-23 09:26:45.402356+00	2023-08-23 09:26:45.402356+00	https://th.bing.com/th/id/OIP.0nYrUVM8oaaziaQbtMQ7pAHaEK?pid=ImgDet&rs=1	\N
19	Unreal Engine	2023-08-23 09:26:56.391575+00	2023-08-23 09:26:56.391575+00	https://wallpapercave.com/wp/wp8038843.jpg	\N
15	Flutter	2023-08-23 03:54:31.453298+00	2023-08-23 07:13:21.744273+00	https://images.hdqwalls.com/wallpapers/flutter-logo-4k-qn.jpg	\N
26	Swift	2023-09-19 07:49:51.389318+00	2023-09-19 07:49:51.389318+00	https://1000marcas.net/wp-content/uploads/2021/06/Swift-Logo.png	\N
24	NodeJS	2023-08-28 04:30:24.791279+00	2023-08-28 04:30:24.791279+00	https://innovationyourself.com/wp-content/uploads/2020/08/nodejs-logo.png	\N
20	Godot	2023-08-23 09:26:59.913741+00	2023-08-23 09:26:59.913741+00	https://img.itch.zone/aW1hZ2UvOTQ2NzI5LzUzNjY1NzcucG5n/original/sD7KsI.png	\N
22	C++	2023-08-28 04:24:52.722391+00	2023-08-28 04:24:52.722391+00	https://besthqwallpapers.com/Uploads/23-1-2020/119595/thumb2-c---logo-white-silk-texture-c---emblem-programming-language-c--.jpg	\N
16	R Lang	2023-08-23 03:54:36.066346+00	2023-08-28 02:36:01.757747+00	https://courses.javacodegeeks.com/wp-content/uploads/2020/02/2275933_51db-1536x860.jpg	\N
30	Monogatari	2023-11-07 01:17:23.412312+00	2023-11-07 01:17:23.412312+00	https://pbs.twimg.com/media/F-SzWw4akAAVSdm?format=jpg&name=small	\N
29	Tes Flight	2023-11-03 04:41:09.27761+00	2023-11-09 01:21:44.242015+00	https://pbs.twimg.com/media/F-dCZ4PbkAA1CvM?format=jpg&name=small	\N
\.


--
-- Data for Name: contents; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.contents (id_content, content_title, content_type, image, link, id_section, created_at, updated_at) FROM stdin;
10	Apa Itu Python	0012		https://youtu.be/iA8lLwmtKQM	1	2023-08-31 02:22:19.216435+00	2023-08-31 02:22:19.22042+00
11	Twitter	0014		https://twitter.com/registaco/status/1697065397584015593	1	2023-08-31 02:23:17.248729+00	2023-08-31 02:52:21.969853+00
14	Edit Test	0012		https://www.youtube.com/watch?v=-gjzG-FfbAA	8	2023-08-31 22:42:54.981588+00	2023-09-01 02:38:39.191295+00
17	asda	0012		https://youtu.be/iA8lLwmtKQM?si=Y0rwIxTIK7mL-yYi	16	2023-09-02 13:15:03.044001+00	2023-09-02 13:15:03.044001+00
19	PDF Test	0013		http://s29.q4cdn.com/175625835/files/doc_downloads/test.pdf	1	2023-09-05 02:07:12.034734+00	2023-09-05 02:08:02.166589+00
23	aaaaaa	0013		https://upload.wikimedia.org/wikipedia/commons/d/d3/Test.pdf	1	2023-09-05 02:25:22.26716+00	2023-09-05 02:25:22.26716+00
24	Gist Test	0017		https://gist.github.com/mattetti/5914158/f4d1393d83ebedc682a3c8e7bdc6b49670083b84	1	2023-09-05 03:55:20.728417+00	2023-09-05 03:55:20.728417+00
27	Codesandbox Test	0018		https://codesandbox.io/embed/react-editorjs-example-ng6qzo?fontsize=14&hidenavigation=1&theme=dark	1	2023-09-05 04:12:27.168125+00	2023-09-05 04:12:27.168125+00
29	Test Soundcloud	0016		https://soundcloud.com/soundcloud/sets/splash-house-2023	3	2023-09-05 04:27:13.843766+00	2023-09-05 04:27:13.843969+00
18	Youtube Test	0012		https://www.youtube.com/watch?v=dR0-v2OHkCI	1	2023-09-05 01:30:34.095547+00	2023-09-19 01:05:36.356459+00
28	Youtube Test 2	0012		https://www.youtube.com/watch?v=gxmTFXfrMzk	1	2023-09-05 04:14:45.958079+00	2023-09-19 01:05:48.867664+00
30	Tak bisa dihindarkan	0012		https://www.youtube.com/watch?v=-gjzG-FfbAA	22	2023-10-27 04:14:40.791575+00	2023-10-27 04:14:40.791575+00
31	Tak bisa dihindarkan	0012		https://www.youtube.com/watch?v=-gjzG-FfbAA	6	2023-10-27 04:15:17.796039+00	2023-10-27 04:15:17.796039+00
32	Variabel	0012		https://www.youtube.com/watch?v=-gjzG-FfbAA	23	2023-10-27 04:25:48.507661+00	2023-10-27 04:25:48.507661+00
33	Apa itu Flutter	0012		https://www.youtube.com/watch?v=odjuVCHNat8	23	2023-10-27 04:26:52.268739+00	2023-10-27 04:26:52.268739+00
34	Naruto	0014		http://localhost:3000/dashboard/knowledge/18	23	2023-10-27 04:32:28.038408+00	2023-10-27 04:32:28.038408+00
35	Apa itu Flutter	0012		https://www.youtube.com/watch?v=odjuVCHNat8	19	2023-10-27 04:39:17.852635+00	2023-10-27 04:39:17.852635+00
36	Apa itu Flutter	0012		https://www.youtube.com/watch?v=odjuVCHNat8	1	2023-10-27 04:40:32.638374+00	2023-10-27 04:40:32.638374+00
37	Apa itu Flutter	0012		https://www.youtube.com/watch?v=-gjzG-FfbAA	24	2023-10-27 04:41:22.837281+00	2023-10-27 04:41:22.837281+00
38	Apa itu Flutter	0012		https://www.youtube.com/watch?v=-gjzG-FfbAA	25	2023-10-27 06:02:16.988638+00	2023-10-27 06:02:16.988638+00
41	Vtuber	0012			31	2023-11-03 09:03:38.864437+00	2023-11-03 09:03:38.864437+00
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.courses (id_course, id_knowledge, course_name, course_desc, image, date_start, date_end, created_at, updated_at) FROM stdin;
2	1	Pemrograman Lanjutan dengan Python	Kursus ini membawa Anda lebih dalam ke dalam dunia Python. Anda akan mempelajari topik seperti dekorator, manajemen memori, asynchronous programming, dan konsep OOP yang lebih mendalam	https://www.freecodecamp.org/news/content/images/2022/02/Banner-10.png	2023-08-30 17:00:00+00	2023-09-28 17:00:00+00	2023-08-30 07:23:25.727427+00	2023-09-19 02:08:40.059403+00
3	5	Pengembangan Game 3D dengan Unity	Kursus ini membawa Anda ke tingkat berikutnya dalam pengembangan game dengan Unity. Anda akan mempelajari pembuatan lingkungan 3D, fisika simulasi, efek visual, dan integrasi multiplayer.	https://www.cdmi.in/courses@2x/unity.webp	2023-08-30 17:00:00+00	2023-10-26 17:00:00+00	2023-08-30 07:26:35.675484+00	2023-09-20 08:22:04.411404+00
4	2	Desain Elegan dengan Flutter	Pahami seni desain dengan Flutter! Dalam kursus ini, Anda akan mempelajari cara menghasilkan antarmuka pengguna yang elegan dan menawan menggunakan Flutter. Dari desain material hingga kreasi desain khusus, Anda akan menguasai seni desain untuk aplikasi mobile.	https://swapps.com/wp-content/uploads/2018/07/trying-out-flutter.jpg	2023-09-18 17:00:00+00	2023-10-12 17:00:00+00	2023-09-19 01:59:39.05692+00	2023-09-21 09:47:20.880969+00
5	2	Membangun Aplikasi AR Flutter	Telusuri dunia AR dengan Flutter! Kursus ini akan membimbing Anda dalam mengembangkan aplikasi augmented reality yang mengagumkan menggunakan Flutter. Anda akan belajar cara menggabungkan dunia nyata dengan elemen-elemen digital dalam aplikasi Anda.	https://pbs.twimg.com/media/F46La-pWoAE3uqr?format=jpg&name=small	2023-09-08 17:00:00+00	2023-09-28 17:00:00+00	2023-09-21 09:48:07.358576+00	2023-10-27 06:35:11.54108+00
7	16	Tes Kursus	adsad	https://pbs.twimg.com/media/FzLcjNdaMAAwz27?format=jpg&name=small	2023-11-28 17:00:00+00	2023-11-22 17:00:00+00	2023-11-06 01:33:28.097521+00	2023-11-06 03:23:30.587248+00
1	1	Python Kursus Pemula	Untuk yang sudah sepuh	https://img-c.udemycdn.com/course/750x422/3218591_fd18_4.jpg	2023-08-24 17:00:00+00	2023-09-29 17:00:00+00	2023-08-24 08:25:58.839551+00	2023-11-07 01:20:36.329468+00
\.


--
-- Data for Name: knowledges; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.knowledges (id_knowledge, knowledge_title, description, status, image, id_category, created_at, updated_at) FROM stdin;
23	Ajukan Pengajuan	Ajukan Pengajuan	0031	https://placehold.co/1280x720	26	2023-11-02 06:02:22.953541+00	2023-11-02 06:02:22.953541+00
3	Ilmu Data dan Analisis menggunakan R	Kursus ini mengajarkan Anda bagaimana menggunakan bahasa pemrograman R untuk menganalisis data. Anda akan belajar eksplorasi data, visualisasi, dan teknik analisis statistik.	0031	https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-course-photos.s3.amazonaws.com/5e/b4ef8069b511e3ae92c39913bb30e0/Rprogramming.jpg?auto=format%2Ccompress&dpr=1	16	2023-08-28 02:32:47.780497+00	2023-09-18 02:35:10.5271+00
4	Pemrograman Java: Konsep dan Praktek	Kursus ini memberikan pemahaman mendalam tentang bahasa pemrograman Java. Anda akan belajar tentang konsep OOP, manipulasi data, dan pengembangan aplikasi Java.	0031	https://mindqsystems.com/wp-content/uploads/2019/08/Core-Java-Training.jpg	17	2023-08-28 04:22:30.148011+00	2023-09-18 02:35:35.270241+00
6	Pemrograman Backend dengan Node.js 	Kursus ini membahas pengembangan backend menggunakan Node.js dan framework Express. Anda akan memahami pembuatan server, routing, dan interaksi dengan database.	0031	https://miro.medium.com/v2/resize:fit:1400/1*xdo0UBpyszvD7-7EH4TkIA.png	24	2023-08-28 04:31:10.766108+00	2023-09-18 02:36:06.614637+00
5	Pengembangan Game 2D dengan Unity	Kursus ini mengajarkan Anda cara membuat game 2D menggunakan engine Unity. Anda akan belajar tentang pembuatan level, animasi, dan interaksi dalam lingkungan game.	0031	https://img-c.udemycdn.com/course/750x422/1210008_6859.jpg	18	2023-08-28 04:27:42.042388+00	2023-09-18 02:36:38.780528+00
13	Pemrograman Shell Scripting dengan Bash	Kursus ini mengajarkan Anda cara membuat skrip shell dengan bahasa Bash di sistem Linux/Unix. Anda akan belajar tentang perulangan, kondisi, dan otomatisasi tugas sistem.	0032	https://cdn.devdojo.com/posts/images/June2019/executing-bash-script-on-multiple-remote-server.jpg?auto=compress&w=960&dpr=2	22	2023-09-19 07:48:19.564896+00	2023-09-19 07:48:19.564896+00
7	Pemrograman PHP Dasar	Kursus ini mengajarkan Anda tentang bahasa pemrograman PHP mulai dari dasar hingga tingkat lanjutan. Anda akan belajar tentang pengembangan web dinamis dan interaksi dengan database.	0031	https://s3.amazonaws.com/coursesity-blog/2019/01/php-1.png	25	2023-08-28 04:40:08.124186+00	2023-09-18 02:33:34.962927+00
14	Mengembangkan Aplikasi iOS dengan Swift	Kursus ini mengajarkan cara mengembangkan aplikasi iOS dengan bahasa pemrograman Swift, dengan fokus pada antarmuka pengguna dan interaksi.	0032	https://blog.arturofm.com/content/images/size/w1000/2021/12/Swift_Lang-1.jpg	26	2023-09-19 07:50:52.052827+00	2023-09-19 07:50:52.052827+00
2	Pengembangan Aplikasi Mobile  Flutter	Kursus ini akan membimbing Anda melalui proses pembuatan aplikasi mobile lintas platform menggunakan framework Flutter. Anda akan mempelajari cara membuat antarmuka pengguna menarik dan mengintegrasikannya dengan logika bisnis	0031	https://cdn.neowin.com/news/images/uploaded/2019/07/1562839325_product_28668_product_shots1_story.jpg	15	2023-08-22 15:09:27.73243+00	2023-09-18 02:34:41.790141+00
15	Analisis Data dengan R	Pelajari bahasa pemrograman R untuk analisis data, termasuk pengolahan data, visualisasi, dan statistik dasar.	0032	https://coursecloud.org/wp-content/uploads/2021/01/48.-Data-Science-Machine-Learning-with-R.jpg	16	2023-09-19 07:54:10.872017+00	2023-09-19 07:54:10.872017+00
16	Kutukan Mantan 	tes	0032	https://placehold.co/1280x720	17	2023-10-26 04:11:34.694972+00	2023-10-27 05:45:48.571553+00
21	Gojo Satoru	Gojo	0032	https://placehold.co/1280x720	22	2023-10-31 12:43:04.901442+00	2023-10-31 12:43:04.901442+00
22	Dagon	Dagon	0032	https://placehold.co/1280x720	22	2023-11-01 01:39:41.411363+00	2023-11-01 01:39:41.411363+00
12	Pengembangan Android dengan Kotlin	Kursus ini mengajarkan Anda cara mengembangkan aplikasi Android menggunakan bahasa Kotlin. Anda akan belajar tentang aktivitas, tata letak, dan interaksi pengguna.	0031	https://pluspng.com/img-png/kotlin-logo-png-kotlin-collection-function-techshots-medium-1200x630.png	14	2023-09-19 07:47:20.38571+00	2023-11-01 07:29:08.45579+00
1	Pemrograman Python untuk Pemula	Kursus ini dirancang untuk mereka yang ingin mempelajari dasar-dasar pemrograman menggunakan bahasa Python. Anda akan belajar tentang sintaks dasar, tipe data, pengendalian alur program, dan konsep dasar pemrograman lainnya	0032	https://static.techspot.com/images2/news/bigimage/2021/03/2021-03-23-image-7.jpg	9	2023-08-22 15:08:32.02848+00	2023-11-01 14:28:34.936339+00
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.posts (id_post, id_threads, user_uuid, content, created_at, updated_at) FROM stdin;
32	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693817164730,"blocks":[{"id":"dvQBYO_arA","type":"paragraph","data":{"text":"Delimiter adalah sebuah perumpamaan yang"}}],"version":"2.28.0"}	2023-09-04 08:46:04.736843+00	2023-09-04 08:46:04.736843+00
33	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693817172751,"blocks":[{"id":"T9jl8Hz9NR","type":"paragraph","data":{"text":"<b>Tes Bold</b>"}}],"version":"2.28.0"}	2023-09-04 08:46:12.756968+00	2023-09-04 08:46:12.756968+00
7	1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693808837633,"blocks":[{"id":"gHsflOpjRz","type":"paragraph","data":{"text":"adad"}}],"version":"2.28.0"}	2023-09-04 06:27:17.640369+00	2023-09-04 06:27:17.640369+00
8	1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693809069852,"blocks":[{"id":"p8mIbAGQbq","type":"paragraph","data":{"text":"adsad"}}],"version":"2.28.0"}	2023-09-04 06:31:09.857188+00	2023-09-04 06:31:09.857188+00
9	1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693809099493,"blocks":[{"id":"6XT1jsDA3f","type":"list","data":{"style":"unordered","items":["Novian Andika","Sonia Eka Putri"]}}],"version":"2.28.0"}	2023-09-04 06:31:39.497806+00	2023-09-04 06:31:39.497806+00
10	1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693809548027,"blocks":[{"id":"4X8ZhjwU7j","type":"paragraph","data":{"text":"asda"}}],"version":"2.28.0"}	2023-09-04 06:39:08.03562+00	2023-09-04 06:39:08.03562+00
11	1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693811281137,"blocks":[{"id":"gEiHxiQfRX","type":"table","data":{"withHeadings":false,"content":[["Novian","Andika"]]}}],"version":"2.28.0"}	2023-09-04 07:08:01.144075+00	2023-09-04 07:08:01.144075+00
12	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693812114265,"blocks":[{"id":"1-owtX8O-M","type":"paragraph","data":{"text":"<b><i>Tes</i></b>"}}],"version":"2.28.0"}	2023-09-04 07:21:54.301774+00	2023-09-04 07:21:54.301774+00
13	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693812407453,"blocks":[{"id":"8x7loOipnd","type":"paragraph","data":{"text":"ss"}}],"version":"2.28.0"}	2023-09-04 07:26:47.459548+00	2023-09-04 07:26:47.459548+00
14	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693812773476,"blocks":[{"id":"q2Q-L1Oq9V","type":"paragraph","data":{"text":"Novian andika"}}],"version":"2.28.0"}	2023-09-04 07:32:53.483344+00	2023-09-04 07:32:53.483344+00
15	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693813220641,"blocks":[{"id":"MXYw_uipya","type":"list","data":{"style":"unordered","items":["Novi"]}}],"version":"2.28.0"}	2023-09-04 07:40:20.646775+00	2023-09-04 07:40:20.646775+00
16	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693814272648,"blocks":[{"id":"K7809yLtCf","type":"paragraph","data":{"text":"Yeah Novian"}},{"id":"IxrCmSqzfg","type":"table","data":{"withHeadings":false,"content":[["adad",""]]}}],"version":"2.28.0"}	2023-09-04 07:57:52.652547+00	2023-09-04 07:57:52.652547+00
17	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693814290302,"blocks":[{"id":"i76_D4HuYM","type":"paragraph","data":{"text":"<b>Novian ANdika</b>"}}],"version":"2.28.0"}	2023-09-04 07:58:10.308312+00	2023-09-04 07:58:10.308312+00
18	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693814585026,"blocks":[{"id":"XE2aHvgFHM","type":"paragraph","data":{"text":"Kok jadi gak sama ya"}}],"version":"2.28.0"}	2023-09-04 08:03:05.031902+00	2023-09-04 08:03:05.031902+00
19	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693814597468,"blocks":[{"id":"nyRVww7be1","type":"paragraph","data":{"text":"Kok&nbsp;"}},{"id":"PcFVjXjhiC","type":"paragraph","data":{"text":"Gitu&nbsp;"}},{"id":"ORB-y-RNPf","type":"paragraph","data":{"text":"Njer"}}],"version":"2.28.0"}	2023-09-04 08:03:17.474687+00	2023-09-04 08:03:17.474687+00
20	7	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693816231395,"blocks":[{"id":"5fUIQVRtQ9","type":"paragraph","data":{"text":"sdasd"}}],"version":"2.28.0"}	2023-09-04 08:30:31.400667+00	2023-09-04 08:30:31.400667+00
21	7	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693816251775,"blocks":[{"id":"_Iz8qVVVp0","type":"paragraph","data":{"text":"nigger"}}],"version":"2.28.0"}	2023-09-04 08:30:51.78024+00	2023-09-04 08:30:51.78024+00
22	7	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693816256354,"blocks":[{"id":"AFAcQbLq88","type":"paragraph","data":{"text":"nigger aaa"}}],"version":"2.28.0"}	2023-09-04 08:30:56.356855+00	2023-09-04 08:30:56.356855+00
23	7	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693816267226,"blocks":[{"id":"9xMG0Irgcc","type":"paragraph","data":{"text":"<b>Novian Andika</b>"}}],"version":"2.28.0"}	2023-09-04 08:31:07.232692+00	2023-09-04 08:31:07.232692+00
24	7	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693816275066,"blocks":[{"id":"u6wscRSdNZ","type":"paragraph","data":{"text":"asdajdjadn asdasdasd adasd"}}],"version":"2.28.0"}	2023-09-04 08:31:15.072852+00	2023-09-04 08:31:15.072852+00
25	1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693816663700,"blocks":[{"id":"CqrhSVdBlg","type":"paragraph","data":{"text":"<b><i>Hiyaa gimana</i></b>"}}],"version":"2.28.0"}	2023-09-04 08:37:43.706458+00	2023-09-04 08:37:43.706458+00
26	1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693816698529,"blocks":[{"id":"C2vsPFWn1m","type":"table","data":{"withHeadings":false,"content":[["adasd","asdas"],["adsasd","dasdsa"],["asdasd","asdas"]]}},{"id":"mNdPeZ_PQU","type":"code","data":{"code":"adadad"}}],"version":"2.28.0"}	2023-09-04 08:38:18.535767+00	2023-09-04 08:38:18.535767+00
27	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693816935688,"blocks":[{"id":"leAmBgdnGy","type":"list","data":{"style":"ordered","items":["ad","asdsa","da","ads","dsa","dasd"]}}],"version":"2.28.0"}	2023-09-04 08:42:15.693996+00	2023-09-04 08:42:15.693996+00
28	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693817102728,"blocks":[],"version":"2.28.0"}	2023-09-04 08:45:02.733434+00	2023-09-04 08:45:02.733434+00
29	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693817124122,"blocks":[],"version":"2.28.0"}	2023-09-04 08:45:24.130075+00	2023-09-04 08:45:24.130075+00
30	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693817135552,"blocks":[{"id":"4443oD9_2y","type":"paragraph","data":{"text":"nOVIAN ANDIKADASDSA"}}],"version":"2.28.0"}	2023-09-04 08:45:35.558798+00	2023-09-04 08:45:35.558798+00
31	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693817144626,"blocks":[{"id":"mbkpd5TpPN","type":"paragraph","data":{"text":"aoarakajs askdjak asdjkajdsa asdsa das"}}],"version":"2.28.0"}	2023-09-04 08:45:44.632514+00	2023-09-04 08:45:44.632514+00
40	6	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693817618339,"blocks":[{"id":"H1DiCJtJPZ","type":"paragraph","data":{"text":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."}}],"version":"2.28.0"}	2023-09-04 08:53:38.344585+00	2023-09-04 08:53:38.344585+00
41	6	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693817690974,"blocks":[{"id":"W1B5LXVh7n","type":"linkTool","data":{"link":"https://elearning.ut.ac.id/grade/report/overview/index.php","meta":{}}}],"version":"2.28.0"}	2023-09-04 08:54:50.979983+00	2023-09-04 08:54:50.979983+00
42	6	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693818002630,"blocks":[{"id":"woLESQbY-Z","type":"code","data":{"code":"const MAX_PRIME = 1000000;\\n\\nfunction isPrime(n) {\\n  for (let i = 2; i <= Math.sqrt(n); i++) {\\n    if (n % i === 0) {\\n      return false;\\n    }\\n  }\\n  return n > 1;\\n}\\n\\nconst random = (max) => Math.floor(Math.random() * max);\\n\\nfunction generatePrimes(quota) {\\n  const primes = [];\\n  while (primes.length < quota) {\\n    const candidate = random(MAX_PRIME);\\n    if (isPrime(candidate)) {\\n      primes.push(candidate);\\n    }\\n  }\\n  return primes;\\n}\\n\\nconst quota = document.querySelector(\\"#quota\\");\\nconst output = document.querySelector(\\"#output\\");\\n\\ndocument.querySelector(\\"#generate\\").addEventListener(\\"click\\", () => {\\n  const primes = generatePrimes(quota.value);\\n  output.textContent = `Finished generating ${quota.value} primes!`;\\n});\\n\\ndocument.querySelector(\\"#reload\\").addEventListener(\\"click\\", () => {\\n  document.location.reload();\\n});\\n"}}],"version":"2.28.0"}	2023-09-04 09:00:02.63984+00	2023-09-04 09:00:02.63984+00
43	6	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693818493173,"blocks":[{"id":"erJP-ohB9Y","type":"list","data":{"style":"ordered","items":["Novian","Andika","Hehe"]}}],"version":"2.28.0"}	2023-09-04 09:08:13.17918+00	2023-09-04 09:08:13.17918+00
44	15	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693819018861,"blocks":[{"id":"t-UG1_1yht","type":"paragraph","data":{"text":"Aghanim Scepter membutuhkan <b><i>Staff Of Wizardry, Ogre Axe, Blade Of Alacrity</i> </b>serta <b><i>Point Booster</i></b>"}},{"id":"KKxC5l7crh","type":"paragraph","data":{"text":"Semoga bisa membantu"}}],"version":"2.28.0"}	2023-09-04 09:16:58.868192+00	2023-09-04 09:16:58.868192+00
45	16	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	{"time":1693820825645,"blocks":[{"id":"JHDD_OYAM_","type":"paragraph","data":{"text":"Aku tidak tahu caranya tolong ajarkan puh"}}],"version":"2.28.0"}	2023-09-04 09:47:05.650273+00	2023-09-04 09:47:05.650273+00
46	16	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693820855832,"blocks":[{"id":"nWyQvE7Eu5","type":"paragraph","data":{"text":"Puh"}}],"version":"2.28.0"}	2023-09-04 09:47:35.838767+00	2023-09-04 09:47:35.838767+00
47	16	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	{"time":1693820998427,"blocks":[{"id":"THgv4LzrU2","type":"paragraph","data":{"text":"<b><i>Orang kamu yang sepuh kok</i></b>"}}],"version":"2.28.0"}	2023-09-04 09:49:58.432092+00	2023-09-04 09:49:58.432092+00
48	16	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693821052182,"blocks":[{"id":"pxebb1tcMe","type":"paragraph","data":{"text":"becanda bang"}}],"version":"2.28.0"}	2023-09-04 09:50:52.186298+00	2023-09-04 09:50:52.186298+00
49	17	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	{"time":1693821179954,"blocks":[{"id":"UlEZzhcBUZ","type":"paragraph","data":{"text":"Sepertinya gak bisa puh"}}],"version":"2.28.0"}	2023-09-04 09:52:59.960688+00	2023-09-04 09:52:59.960688+00
50	17	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	{"time":1693821530085,"blocks":[{"id":"y22nhc28CY","type":"paragraph","data":{"text":"oh begitu"}}],"version":"2.28.0"}	2023-09-04 09:58:50.090068+00	2023-09-04 09:58:50.090068+00
51	17	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693821745912,"blocks":[{"id":"QbOayYNomX","type":"paragraph","data":{"text":"halo"}}],"version":"2.28.0"}	2023-09-04 10:02:25.919739+00	2023-09-04 10:02:25.919739+00
52	17	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693822024470,"blocks":[{"id":"6CpPSPXG9R","type":"paragraph","data":{"text":"hi"}}],"version":"2.28.0"}	2023-09-04 10:07:04.475742+00	2023-09-04 10:07:04.475742+00
53	17	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	{"time":1693822054307,"blocks":[{"id":"RYX-weaBJ7","type":"paragraph","data":{"text":"apa kah ini&nbsp;"}}],"version":"2.28.0"}	2023-09-04 10:07:34.313092+00	2023-09-04 10:07:34.313092+00
54	1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693866220651,"blocks":[{"id":"ZK1yNgg3L2","type":"paragraph","data":{"text":"Why wont it work"}}],"version":"2.28.0"}	2023-09-04 22:23:40.660677+00	2023-09-04 22:23:40.660677+00
55	17	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1693971447031,"blocks":[{"id":"zgq3VkE-0d","type":"paragraph","data":{"text":"gak bisa install unity woy di linux windows 4 life"}}],"version":"2.28.0"}	2023-09-06 03:37:27.047451+00	2023-09-06 03:37:27.047451+00
56	17	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1694154127919,"blocks":[{"id":"HnFtz_LEso","type":"paragraph","data":{"text":"hehe"}}],"version":"2.28.0"}	2023-09-08 06:22:07.925905+00	2023-09-08 06:22:07.925905+00
57	18	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1694405984346,"blocks":[{"id":"SymeLhYkyZ","type":"paragraph","data":{"text":"asdasdasd"}}],"version":"2.28.0"}	2023-09-11 04:19:44.354742+00	2023-09-11 04:19:44.354742+00
58	3	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1695048174377,"blocks":[{"id":"63UCCJofm5","type":"paragraph","data":{"text":"Nahida adalah Archon Sumeru"}}],"version":"2.28.0"}	2023-09-18 14:42:54.382755+00	2023-09-18 14:42:54.382755+00
59	2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1695052740534,"blocks":[{"id":"sGlemtrDfM","type":"code","data":{"code":"sdfsdf"}}],"version":"2.28.0"}	2023-09-18 15:59:00.54037+00	2023-09-18 15:59:00.54037+00
60	4	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1695052858157,"blocks":[{"id":"FHfXuhQxtL","type":"list","data":{"style":"ordered","items":["sad"]}}],"version":"2.28.0"}	2023-09-18 16:00:58.161087+00	2023-09-18 16:00:58.161087+00
61	4	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1695053404276,"blocks":[{"id":"3LeOlirpgh","type":"list","data":{"style":"ordered","items":["Novian Andika"]}},{"id":"wqppmqr5pm","type":"list","data":{"style":"unordered","items":["aadasd"]}}],"version":"2.28.0"}	2023-09-18 16:10:04.28214+00	2023-09-18 16:10:04.28214+00
62	4	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1695053461162,"blocks":[{"id":"q0wMStIRCO","type":"table","data":{"withHeadings":false,"content":[["Novian","Andika","Dunno","Whateva"],["Haha","Hihi","adad","asdasd"]]}}],"version":"2.28.0"}	2023-09-18 16:11:01.177265+00	2023-09-18 16:11:01.177265+00
63	4	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1695053650090,"blocks":[{"id":"FIVtAX6-kN","type":"header","data":{"text":"ADASD","level":2}}],"version":"2.28.0"}	2023-09-18 16:14:10.094106+00	2023-09-18 16:14:10.094106+00
64	4	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1695053708093,"blocks":[{"id":"I4AidLMVyp","type":"paragraph","data":{"text":"Ini paragraph"}},{"id":"mJhxfe-MrP","type":"paragraph","data":{"text":"yang baik"}}],"version":"2.28.0"}	2023-09-18 16:15:08.098081+00	2023-09-18 16:15:08.098081+00
65	4	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1695053917511,"blocks":[{"id":"4UObMkRLOI","type":"table","data":{"withHeadings":false,"content":[["Border","Radius"],["1","80"]]}}],"version":"2.28.0"}	2023-09-18 16:18:37.516282+00	2023-09-18 16:18:37.516282+00
66	19	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1695089447859,"blocks":[{"id":"wvSMaAHL3r","type":"paragraph","data":{"text":"Hello"}}],"version":"2.28.0"}	2023-09-19 02:10:47.866055+00	2023-09-19 02:10:47.866055+00
67	16	524101f8-69d8-4d35-adeb-8406e39cd2f1	{"time":1695354919674,"blocks":[{"id":"1Nh4mWrZT2","type":"paragraph","data":{"text":"ya gak tau kok tanya saya"}}],"version":"2.28.0"}	2023-09-22 03:55:19.680655+00	2023-09-22 03:55:19.680655+00
68	3	524101f8-69d8-4d35-adeb-8406e39cd2f1	{"time":1695356079579,"blocks":[{"id":"Vjp_dZgvyk","type":"paragraph","data":{"text":"Bukan nahida itu archon Monstadnt"}}],"version":"2.28.0"}	2023-09-22 04:14:39.584123+00	2023-09-22 04:14:39.584123+00
69	15	524101f8-69d8-4d35-adeb-8406e39cd2f1	{"time":1695356113294,"blocks":[{"id":"VQnyZCevgV","type":"paragraph","data":{"text":"Aghanim gratis dari roshan"}}],"version":"2.28.0"}	2023-09-22 04:15:13.299961+00	2023-09-22 04:15:13.299961+00
70	4	524101f8-69d8-4d35-adeb-8406e39cd2f1	{"time":1695356490387,"blocks":[{"id":"J5c0aOkMy6","type":"paragraph","data":{"text":"<b>gajelas njer</b>"}}],"version":"2.28.0"}	2023-09-22 04:21:30.394564+00	2023-09-22 04:21:30.394564+00
71	18	524101f8-69d8-4d35-adeb-8406e39cd2f1	{"time":1695356667155,"blocks":[{"id":"xpTpEkVfBq","type":"paragraph","data":{"text":"tes tes 123131312"}}],"version":"2.28.0"}	2023-09-22 04:24:27.161583+00	2023-09-22 04:24:27.161583+00
72	1	524101f8-69d8-4d35-adeb-8406e39cd2f1	{"time":1695881972670,"blocks":[{"id":"o356sbnFtN","type":"paragraph","data":{"text":"Lu gak diajak"}}],"version":"2.28.0"}	2023-09-28 06:19:32.680452+00	2023-09-28 06:19:32.680452+00
73	1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1695986013565,"blocks":[{"id":"FhCf17pQF_","type":"paragraph","data":{"text":"tse"}}],"version":"2.28.0"}	2023-09-29 11:13:33.571775+00	2023-09-29 11:13:33.571775+00
74	1	524101f8-69d8-4d35-adeb-8406e39cd2f1	{"time":1698334929451,"blocks":[{"id":"UM5Ud62bpj","type":"paragraph","data":{"text":"Kobokan aer"}}],"version":"2.28.0"}	2023-10-26 15:42:09.463137+00	2023-10-26 15:42:09.463137+00
75	1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1698390258085,"blocks":[{"id":"aG4BoGrtw_","type":"paragraph","data":{"text":"asdsad"}}],"version":"2.28.0"}	2023-10-27 07:04:18.090941+00	2023-10-27 07:04:18.090941+00
76	21	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	{"time":1698392892028,"blocks":[{"id":"ZaVPxhSp3Z","type":"paragraph","data":{"text":"Hiyaa"}}],"version":"2.28.0"}	2023-10-27 07:48:12.034816+00	2023-10-27 07:48:12.034816+00
77	1	524101f8-69d8-4d35-adeb-8406e39cd2f1	{"time":1698742015264,"blocks":[{"id":"EnyMvn2RMo","type":"paragraph","data":{"text":"Kawaiku&nbsp;"}}],"version":"2.28.0"}	2023-10-31 08:46:55.270081+00	2023-10-31 08:46:55.270081+00
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.questions (id_question, id_quiz, question_text) FROM stdin;
1	1	Apa output dari kode berikut? print(2 + 3 * 5)
2	1	Apa tipe data yang digunakan untuk menyimpan frasa atau teks di Python?
3	1	Bagaimana cara menginisialisasi sebuah list kosong di Python?
4	2	Apa kepanjangan dari HTML?
5	2	Apa fungsi utama dari CSS dalam pengembangan web?
6	2	Apa perbedaan antara tag <div> dan <span> dalam HTML?
7	4	Test Pertanyaan
8	4	Tes added question
9	6	Apa itu Pandas?
10	6	Apa fungsi utama Pandas DataFrame?
11	6	Bagaimana cara membaca data dari file CSV menggunakan Pandas?
12	6	Apa yang dilakukan metode .head() pada Pandas DataFrame?
13	6	Apa perbedaan antara Series dan DataFrame dalam Pandas?
14	6	Apa yang dimaksud dengan 'index' dalam Pandas DataFrame?
15	6	Apa perbedaan antara loc[] dan iloc[] dalam Pandas?
16	6	Bagaimana cara menghapus kolom dalam Pandas DataFrame?
17	6	Apa yang dilakukan metode .describe() pada Pandas DataFrame?
18	6	Bagaimana cara mengganti nama kolom dalam Pandas DataFrame?
19	6	Apa yang dimaksud dengan 'groupby' dalam Pandas?
20	12	Siapa nama dirut Bank BPD DIY
21	12	Apa kepanjangan dari HTML?
22	1	Siapa nama dirut Bank BPD DIY
\.


--
-- Data for Name: quizzes; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.quizzes (id_quiz, quiz_title, quiz_desc, quiz_type, created_at, id_section, status_text) FROM stdin;
4	Kuis Pemrograman Lanjutan dengan Python	Kuis ini menguji pemahaman Anda tentang konsep pemrograman lanjutan dalam bahasa Python, termasuk objek, class, dan error handling	0022	2023-08-29 08:36:47.782+00	\N	\N
5	Kuis Pengembangan Web Dinamis dengan JavaScript	Kuis ini menguji pemahaman Anda tentang pengembangan web dinamis menggunakan bahasa pemrograman JavaScript.	0022	2023-08-29 08:40:15.583+00	\N	\N
7	Kuis Pengembangan Aplikasi Mobile dengan Flutter	Kuis ini menguji pemahaman Anda tentang pengembangan aplikasi mobile menggunakan framework Flutter.	0022	2023-08-29 08:41:05.306+00	\N	\N
8	Kuis Algoritma dan Struktur Data	Kuis ini menguji pemahaman Anda tentang algoritma dan struktur data, termasuk sorting, searching, dan kompleksitas waktu.	0022	2023-08-29 08:48:32.414+00	\N	\N
11	Kuis Basis Data Relasion	Kuis ini menguji pemahaman Anda tentang penggunaan SQL dalam manajemen basis data relasional.	0022	2023-08-29 03:14:42.358786+00	\N	\N
1	Kuis Dasar Pemrograman Python	Kuis ini menguji pemahaman Anda tentang dasar-dasar bahasa pemrograman Python, termasuk sintaks, tipe data, dan pengendalian alur program.	0021	2023-08-28 08:59:58.238+00	8	\N
3	Kuis Dasar Kecerdasan Buatan	Kuis ini menguji pemahaman Anda tentang konsep dasar kecerdasan buatan, machine learning, dan neural network.	0021	2023-08-29 08:30:25.775+00	10	\N
9	Kuis Keamanan Aplikasi Web	Kuis ini menguji pemahaman Anda tentang aspek keamanan dalam pengembangan aplikasi web.	0022	2023-08-29 08:48:50.325+00	8	\N
10	Kuis Machine Learning dan Neural Network	Kuis ini menguji pemahaman Anda tentang konsep machine learning, neural network, dan penerapannya dalam analisis data.	0022	2023-08-29 08:49:16.667+00	8	\N
2	Kuis Pemahaman HTML dan CSS	Kuis ini menguji pemahaman Anda tentang HTML (HyperText Markup Language) dan CSS (Cascading Style Sheets) untuk pengembangan web.	0021	2023-08-29 08:29:45.137+00	8	\N
6	Kuis Analisis Data dengan Pandas	Kuis ini menguji pemahaman Anda tentang pengolahan dan analisis data menggunakan library Pandas di Python.	0022	2023-08-29 08:41:03.271+00	16	\N
12	Kutukan Mantan	Tak bisa 	0022	2023-09-19 02:13:36.995111+00	19	\N
\.


--
-- Data for Name: references; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public."references" (id_ref, code_ref1, value_ref1, code_ref2) FROM stdin;
6	002	PRE TEST	0021
9	002	EVALUASI	0024
11	003	PRIVATE	0032
8	002	LATIHAN	0023
7	002	POST TEST	0022
10	003	PUBLIC	0031
12	004	BERJALAN	0041
13	004	BELUM MULAI	0042
14	004	SELESAI	0043
3	001	PDF	0013
16	001	SOUNDCLOUD	0016
17	001	GIST	0017
5	001	IMAGE	0015
2	001	YOUTUBE	0012
15	001	CODESANDBOX	0018
4	001	LINK (GENERIC)	0014
18	005	PENDING	0051
19	005	APPROVED	0052
20	005	REJECTED	0053
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.roles (id_role, role_name, role_description, created_at, updated_at) FROM stdin;
1	Admin	Admin can do anything	2023-08-21 01:08:35.435361+00	2023-08-21 01:08:35.435361+00
2	User	User can do anything except create, update, and delete user	2023-08-21 01:08:35.492356+00	2023-08-21 01:08:35.492356+00
3	Pemateri	Nothing	2023-09-20 13:58:01.419+00	2023-09-20 13:58:03.682+00
4	Supervisor	Supervisor can approve pengetahuan dan pelatihan	2023-09-20 13:58:50.018+00	2023-09-20 13:58:51.848+00
\.


--
-- Data for Name: section_course; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.section_course (course_id_course, section_id_section) FROM stdin;
1	8
3	10
1	16
4	19
2	20
2	21
7	32
\.


--
-- Data for Name: section_knowledge; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.section_knowledge (section_id_section, knowledge_id_knowledge) FROM stdin;
1	1
3	1
4	1
6	2
7	2
9	7
18	3
24	16
29	22
31	23
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.sections (id_section, section_title, created_at, updated_at) FROM stdin;
1	Pengenalan Python	2023-08-23 01:17:27.079283+00	2023-08-23 01:17:27.079283+00
3	Fungsi	2023-08-23 01:17:52.713897+00	2023-08-23 01:17:52.713897+00
4	List dan Tuple	2023-08-23 01:18:19.888416+00	2023-08-23 01:18:19.888416+00
6	Pendahuluan	2023-08-24 07:24:07.434717+00	2023-08-24 07:24:07.434717+00
7	Instalasi Flutter	2023-08-24 07:24:15.292268+00	2023-08-24 07:24:15.292268+00
9	Pendahuluan	2023-08-30 09:25:23.340938+00	2023-08-30 09:25:23.340938+00
10	Kuis Unity Dasar	2023-08-30 22:52:25.898455+00	2023-08-30 22:52:41.155222+00
11	hehr	2023-08-31 14:42:55.37605+00	2023-08-31 14:42:55.37605+00
12	hehr	2023-08-31 14:45:41.993944+00	2023-08-31 14:45:41.993944+00
13	hehr	2023-08-31 14:46:03.725408+00	2023-08-31 14:46:03.725408+00
8	Minggu 1	2023-08-29 04:23:46.527488+00	2023-09-05 13:11:23.61723+00
16	Minggu 2	2023-09-01 03:46:01.449837+00	2023-09-15 07:52:22.13787+00
18	Pendahuluan	2023-09-16 15:04:36.095336+00	2023-09-16 15:04:36.095336+00
20	Pendahuluan	2023-09-19 02:04:29.630368+00	2023-09-19 02:04:29.630368+00
21	A	2023-09-19 02:08:40.214682+00	2023-09-19 02:08:40.214682+00
19	Pendahuluan	2023-09-19 02:00:02.012644+00	2023-09-19 02:18:06.099568+00
22	Pendahuluan	2023-10-27 04:14:17.157272+00	2023-10-27 04:14:17.157272+00
23	Sakura Miko	2023-10-27 04:25:36.169973+00	2023-10-27 04:25:36.169973+00
24	Penda	2023-10-27 04:41:13.687675+00	2023-10-27 04:41:13.687675+00
25	Sakura Miko	2023-10-27 06:00:56.935042+00	2023-10-27 06:00:56.935042+00
27	aaa	2023-10-27 06:18:05.425226+00	2023-10-27 06:18:05.425226+00
28	Heya	2023-10-30 03:52:57.320391+00	2023-10-30 03:52:57.320391+00
29	Mahito	2023-11-01 02:32:26.212492+00	2023-11-01 02:32:26.212492+00
31	Pendahuluan	2023-11-03 09:03:03.160651+00	2023-11-03 09:03:03.161649+00
32	Pelatihan Dasar	2023-11-06 03:23:30.718107+00	2023-11-06 03:23:30.718107+00
\.


--
-- Data for Name: threads; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.threads (id_threads, id_course, threads_title, created_at, updated_at) FROM stdin;
1	1	Halo Halo	2023-09-01 13:19:54.647+00	2023-09-01 13:19:56.637+00
2	1	Bahasan Ke 2	2023-09-01 13:38:31.027+00	2023-09-01 13:38:32.357+00
4	1	Bagaimana caranya membuka notepad	2023-09-01 17:06:24.477+00	2023-09-01 17:06:26.418+00
6	1	Ulti venti	2023-09-01 17:06:27.09+00	2023-09-01 17:06:28.252+00
3	1	Nahida siapa 	2023-09-01 17:06:31.336+00	2023-09-01 17:06:32.193+00
7	1	Dota 2 update ?	2023-09-01 17:06:29.725+00	2023-09-01 17:06:30.571+00
5	1	Apa yang sedang anda lakukan	2023-09-01 17:06:33.489+00	2023-09-01 17:06:34.414+00
9	1	Anjing	2023-09-02 01:47:31.323699+00	2023-09-02 01:47:31.323699+00
10	1	aaaaa	2023-09-02 13:13:31.645712+00	2023-09-02 13:13:31.645712+00
11	1	asadasd	2023-09-02 13:22:00.611972+00	2023-09-02 13:22:00.611972+00
12	1	asa	2023-09-02 13:22:37.304468+00	2023-09-02 13:22:37.304468+00
13	1	aaaXZcxz	2023-09-02 13:23:16.891478+00	2023-09-02 13:23:16.891478+00
14	1	Topik ini\n	2023-09-02 13:28:52.938633+00	2023-09-02 13:28:52.938633+00
15	1	Bagaimana cara membuat Aghanim Scepter di Dota 2\n	2023-09-03 02:16:04.464285+00	2023-09-03 02:16:04.464285+00
16	3	Bagaimana cara menginstall Unity di Windows ?	2023-09-04 09:46:24.386053+00	2023-09-04 09:46:24.386053+00
17	3	Bagaimana cara menginstall unity di Linux ?	2023-09-04 09:52:40.087892+00	2023-09-04 09:52:40.087892+00
18	1	Apa itu bla ?	2023-09-11 04:18:27.112738+00	2023-09-11 04:18:27.112738+00
19	2	Test Forum\n	2023-09-19 02:10:38.295908+00	2023-09-19 02:10:38.295908+00
20	1	sa	2023-10-27 07:14:18.271586+00	2023-10-27 07:14:18.271586+00
21	5	Tes\n	2023-10-27 07:14:44.570817+00	2023-10-27 07:14:44.570817+00
22	5	asdad	2023-10-27 07:14:58.625099+00	2023-10-27 07:14:58.625099+00
23	5	AAAAA	2023-10-27 07:16:41.510565+00	2023-10-27 07:16:41.510565+00
24	1	AASDASD	2023-10-27 07:25:32.82552+00	2023-10-27 07:25:32.82552+00
25	1	A	2023-10-27 07:31:28.275455+00	2023-10-27 07:31:28.275455+00
26	1	Nice\n	2023-10-31 08:08:44.256803+00	2023-10-31 08:08:44.256803+00
\.


--
-- Data for Name: user_course; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.user_course (course_id_course, user_uuid) FROM stdin;
3	02cf0f69-55bb-4ff7-8efd-9fc06353fec5
1	fa158071-f33c-40e7-a5e1-0448b3cfd9eb
1	e041688d-d8ca-44ec-80c4-90641174b63b
1	6bf6c3e4-c20d-42f2-a7fd-daab71db7c4e
1	58d76fc2-db09-491a-8387-f2a5750b64e3
1	dfdd8512-d688-47af-bcfc-7e1f676a651c
2	02cf0f69-55bb-4ff7-8efd-9fc06353fec5
1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5
1	cf97bdce-fd2d-415c-8ae7-7f998e2b1987
1	524101f8-69d8-4d35-adeb-8406e39cd2f1
2	cf97bdce-fd2d-415c-8ae7-7f998e2b1987
2	524101f8-69d8-4d35-adeb-8406e39cd2f1
4	02cf0f69-55bb-4ff7-8efd-9fc06353fec5
4	cf97bdce-fd2d-415c-8ae7-7f998e2b1987
3	524101f8-69d8-4d35-adeb-8406e39cd2f1
1	f0377dc5-12f2-4a68-8687-5de92c347cb4
5	f0377dc5-12f2-4a68-8687-5de92c347cb4
7	524101f8-69d8-4d35-adeb-8406e39cd2f1
1	41ae30e4-22ff-47ce-a28f-b7920b633c56
\.


--
-- Data for Name: user_fav_knowledge; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.user_fav_knowledge (users_uuid) FROM stdin;
\.


--
-- Data for Name: user_quizzes; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.user_quizzes (id_user_quiz, user_uuid, id_quiz, score, selected_answers) FROM stdin;
3	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	1	100	{"1": 3, "2": 6, "3": 9}
4	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	1	66	{"1": 3, "2": 1, "3": 9}
5	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	1	100	{"1": 3, "2": 6, "3": 9}
6	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2	100	{"4": 13, "5": 18, "6": 23}
7	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	1	66	{"1": 1, "2": 6, "3": 9}
8	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	1	0	{"1": 1, "2": 7, "3": 10}
9	02cf0f69-55bb-4ff7-8efd-9fc06353fec5	12	0	{"20": 76, "21": 82}
10	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	12	100	{"20": 79, "21": 80}
11	cf97bdce-fd2d-415c-8ae7-7f998e2b1987	12	50	{"20": 77, "21": 80}
14	524101f8-69d8-4d35-adeb-8406e39cd2f1	2	33	{"4": 13, "5": 17, "6": 21}
15	524101f8-69d8-4d35-adeb-8406e39cd2f1	1	33	{"1": 1, "2": 7, "3": 9}
16	524101f8-69d8-4d35-adeb-8406e39cd2f1	6	27	{"9": 32, "10": 37, "11": 40, "12": 45, "13": 51, "14": 52, "15": 57, "16": 61, "17": 64, "18": 68, "19": 72}
17	524101f8-69d8-4d35-adeb-8406e39cd2f1	1	0	{"1": 1, "2": 5, "3": 10}
18	524101f8-69d8-4d35-adeb-8406e39cd2f1	1	66	{"1": 1, "2": 6, "3": 9}
22	524101f8-69d8-4d35-adeb-8406e39cd2f1	1	33	{"1": 1, "2": 6, "3": 10}
23	524101f8-69d8-4d35-adeb-8406e39cd2f1	6	18	{"9": 32, "10": 39, "11": 40, "12": 45, "13": 49, "14": 54, "15": 57, "16": 60, "17": 64, "18": 69, "19": 72}
24	524101f8-69d8-4d35-adeb-8406e39cd2f1	1	100	{"1": 3, "2": 6, "3": 9}
25	524101f8-69d8-4d35-adeb-8406e39cd2f1	2	100	{"4": 13, "5": 18, "6": 23}
26	524101f8-69d8-4d35-adeb-8406e39cd2f1	1	100	{"1": 3, "2": 6, "3": 9}
27	524101f8-69d8-4d35-adeb-8406e39cd2f1	1	66	{"1": 1, "2": 6, "3": 9}
28	524101f8-69d8-4d35-adeb-8406e39cd2f1	1	0	{"1": 1, "2": 7, "3": 10}
29	f0377dc5-12f2-4a68-8687-5de92c347cb4	1	100	{"1": 3, "2": 6, "3": 9}
30	524101f8-69d8-4d35-adeb-8406e39cd2f1	1	75	{"1": 2, "2": 6, "3": 9, "22": 84}
\.


--
-- Data for Name: user_role; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.user_role (role_id_role, user_uuid) FROM stdin;
1	02cf0f69-55bb-4ff7-8efd-9fc06353fec5
2	524101f8-69d8-4d35-adeb-8406e39cd2f1
2	ff3f58e4-8821-4287-b9b3-d67de7a9c243
1	cf97bdce-fd2d-415c-8ae7-7f998e2b1987
1	b3b9b16c-490f-4b02-9ab6-f7cca037f08b
4	58d76fc2-db09-491a-8387-f2a5750b64e3
4	e041688d-d8ca-44ec-80c4-90641174b63b
4	dfdd8512-d688-47af-bcfc-7e1f676a651c
4	6bf6c3e4-c20d-42f2-a7fd-daab71db7c4e
4	fa158071-f33c-40e7-a5e1-0448b3cfd9eb
3	ee142245-e23e-42e2-8512-1f15ae55b727
3	41ae30e4-22ff-47ce-a28f-b7920b633c56
3	f0377dc5-12f2-4a68-8687-5de92c347cb4
3	197aad55-b0bb-4c5c-bee2-aa3399b35214
3	b31b5e2f-c79f-4ae9-8a9d-7592150270b7
2	ff740422-ba3e-46c2-a161-b667eb591233
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: fleetimee
--

COPY public.users (uuid, created_at, updated_at, deleted_at, username, email, password, last_login) FROM stdin;
6bf6c3e4-c20d-42f2-a7fd-daab71db7c4e	2023-08-27 07:49:07.286842+00	2023-09-21 09:35:49.772521+00	\N	candice	candice@gmail.com	$2a$14$IRuUfj/OAouqORNhfHm5.ez7n4duWm2dzKfrgyMVQvP.nqsVNF4ue	2023-09-21 09:35:49.772521+00
ee142245-e23e-42e2-8512-1f15ae55b727	2023-11-06 17:58:33.196185+00	2023-11-06 21:22:46.840805+00	\N	terezia	terezia@gmail.com	$2a$14$gryk3i/04NN.bbihe/sP2enfwUreSLV5rtT2vE0b/8N4UgChfs1tO	2023-11-06 21:22:46.840805+00
41ae30e4-22ff-47ce-a28f-b7920b633c56	2023-11-06 20:28:05.82874+00	2023-11-08 07:25:10.111076+00	\N	eren	eren@gmail.com	$2a$14$edhD0F3aj3nVhnapvVZbN.Jg.A7DbJvV9iKrqKRG8NR1nPskBpyZu	2023-11-08 07:25:10.111076+00
cf97bdce-fd2d-415c-8ae7-7f998e2b1987	2023-08-21 01:11:17.969885+00	2023-11-08 07:25:46.762751+00	\N	novian	novian123@gmail.com	$2a$14$VnMmagbUKr0bAWaLQveLVuCklNRY3fZD86RZyGXof7BVwcPjTDqcS	2023-11-08 07:25:46.762751+00
58d76fc2-db09-491a-8387-f2a5750b64e3	2023-08-27 07:32:32.302154+00	2023-11-06 04:33:53.807396+00	\N	ollie	ollie@gmail.com	$2a$14$VNk7ABjXdyLD0woIqHWuSu7LHclzl1FM7jArvbRqF1nVOXx0MTUIq	2023-11-06 04:33:53.807396+00
b3b9b16c-490f-4b02-9ab6-f7cca037f08b	2023-08-27 07:49:32.139781+00	2023-11-06 05:54:38.252984+00	\N	zeta	zeta@gmail.com	$2a$14$Ue3IjVVftkWId7saWNWtCO1DuyST5USfK91rWUXa9OhEaGfuTyPBW	2023-11-06 05:54:38.252984+00
fa158071-f33c-40e7-a5e1-0448b3cfd9eb	2023-08-27 07:42:24.612806+00	2023-09-21 01:24:56.343382+00	\N	aizen	aizensosuke@gmail.com	$2a$14$UKV2CBsQ9ZKnR1kONnEhwO7FfLrUKNhmK6ZH44bcPjpLse3Me1c5m	2023-09-21 01:24:56.343382+00
524101f8-69d8-4d35-adeb-8406e39cd2f1	2023-08-27 07:30:52.399165+00	2023-11-10 02:51:57.640096+00	\N	kobo	kobokan@gmail.com	$2a$14$hbvbiztrctWk88AzfOeeduaopVjPAY1KtEXO9xYpvgHVkOLcA0cPm	2023-11-10 02:51:57.640096+00
ff3f58e4-8821-4287-b9b3-d67de7a9c243	2023-08-27 07:33:04.583542+00	2023-09-21 01:28:35.860655+00	\N	gura	gawrgura@gmail.com	$2a$14$T0/OZSMICfkHZoiSMejRVOGN6KEGCa3ZHtdCm/fhtXM.vFybUoMve	2023-09-21 01:28:35.860655+00
e041688d-d8ca-44ec-80c4-90641174b63b	2023-08-27 07:18:24.187638+00	2023-11-06 08:51:36.855335+00	\N	pekora	pekora@gmail.com	$2a$14$ZVzCeRvw/83xNEnHyUDjvel.ZWivej2MJVsF7pqLJgPNw/RKmSJ1a	2023-11-06 08:51:36.855335+00
197aad55-b0bb-4c5c-bee2-aa3399b35214	2023-08-27 07:18:48.945215+00	2023-11-13 01:02:55.837314+00	\N	mikosakura	sakuramiko@gmail.com	$2a$14$Le.X.SgZ2fMFiGgUQFfQ6e3zRY2.F27LV.TfmGuls.99ReWzNk4CG	2023-11-13 01:02:55.837314+00
dfdd8512-d688-47af-bcfc-7e1f676a651c	2023-08-27 07:41:47.461516+00	2023-11-06 09:55:46.972676+00	\N	rukia	rukiachan@gmail.com	$2a$14$oWWZe2EN1b3CMCDEUAr/pu9eqwcfrmeG13YwG1JoOAQL5XFWDRAi.	2023-11-06 09:55:46.972676+00
ff740422-ba3e-46c2-a161-b667eb591233	2023-11-13 01:15:59.42322+00	2023-11-13 01:15:59.42322+00	\N	hacken	hacken@gmail.com	$2a$14$tf619nL047GmdwJE8cH83.dty9rdGSCzIlEgOckRjWlMaPYCkRJwy	\N
02cf0f69-55bb-4ff7-8efd-9fc06353fec5	2023-08-21 01:08:35.520515+00	2023-11-13 01:23:36.649402+00	\N	octavia	eax@gmail.com	$2a$14$U8SDOO4z4Blr40w3rBteuO5qbhP/FA84MbY.xCuduuoHwnFfgsEC6	2023-11-13 01:23:36.649402+00
f0377dc5-12f2-4a68-8687-5de92c347cb4	2023-10-27 02:54:17.78864+00	2023-10-27 03:31:57.026702+00	\N	tsubasaa	jonoichi@gmail.com	$2a$14$BUEYhDcUllxARpHr/NJqJeTclHF.v.3dpQPESqCHO6Y6hDULi9.Q.	2023-10-27 03:31:57.026702+00
b31b5e2f-c79f-4ae9-8a9d-7592150270b7	2023-08-25 06:19:23.112735+00	2023-11-06 19:18:20.415175+00	\N	elitehack	zane.227@gmail.com	$2a$14$Is3aO73ivrzclXorZ2iCbOCfCeCw0wJDdSrn9N3fZg.92UMagdD9S	2023-11-06 19:18:20.415175+00
\.


--
-- Name: answers_id_answer_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.answers_id_answer_seq', 87, true);


--
-- Name: approval_course_id_approval_course_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.approval_course_id_approval_course_seq', 8, true);


--
-- Name: approval_knowledge_id_approval_knowledge_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.approval_knowledge_id_approval_knowledge_seq', 27, true);


--
-- Name: category_id_category_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.category_id_category_seq', 30, true);


--
-- Name: contents_id_content_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.contents_id_content_seq', 41, true);


--
-- Name: courses_id_course_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.courses_id_course_seq', 7, true);


--
-- Name: knowledges_id_knowledge_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.knowledges_id_knowledge_seq', 23, true);


--
-- Name: posts_id_post_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.posts_id_post_seq', 77, true);


--
-- Name: questions_id_question_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.questions_id_question_seq', 22, true);


--
-- Name: quizzes_id_quiz_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.quizzes_id_quiz_seq', 12, true);


--
-- Name: references_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.references_id_seq', 20, true);


--
-- Name: roles_id_role_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.roles_id_role_seq', 2, true);


--
-- Name: sections_id_section_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.sections_id_section_seq', 32, true);


--
-- Name: threads_id_threads_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.threads_id_threads_seq', 26, true);


--
-- Name: user_quizzes_id_user_quiz_seq; Type: SEQUENCE SET; Schema: public; Owner: fleetimee
--

SELECT pg_catalog.setval('public.user_quizzes_id_user_quiz_seq', 30, true);


--
-- Name: answers answers_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.answers
    ADD CONSTRAINT answers_pkey PRIMARY KEY (id_answer);


--
-- Name: approval_course approval_course_pk; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_course
    ADD CONSTRAINT approval_course_pk PRIMARY KEY (id_approval_course);


--
-- Name: approval_course approval_course_pk2; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_course
    ADD CONSTRAINT approval_course_pk2 UNIQUE (id_course);


--
-- Name: approval_knowledge approval_knowledge_pk; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_knowledge
    ADD CONSTRAINT approval_knowledge_pk UNIQUE (id_knowledge);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id_category);


--
-- Name: approval_knowledge comment_pk; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_knowledge
    ADD CONSTRAINT comment_pk PRIMARY KEY (id_approval_knowledge);


--
-- Name: contents contents_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.contents
    ADD CONSTRAINT contents_pkey PRIMARY KEY (id_content);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id_course);


--
-- Name: knowledges knowledges_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.knowledges
    ADD CONSTRAINT knowledges_pkey PRIMARY KEY (id_knowledge);


--
-- Name: posts posts_pk; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pk PRIMARY KEY (id_post);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id_question);


--
-- Name: quizzes quizzes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_pkey PRIMARY KEY (id_quiz);


--
-- Name: references references_pk; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public."references"
    ADD CONSTRAINT references_pk PRIMARY KEY (id_ref);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id_role);


--
-- Name: roles roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_name_key UNIQUE (role_name);


--
-- Name: section_course section_course_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.section_course
    ADD CONSTRAINT section_course_pkey PRIMARY KEY (course_id_course, section_id_section);


--
-- Name: section_knowledge section_knowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.section_knowledge
    ADD CONSTRAINT section_knowledge_pkey PRIMARY KEY (section_id_section, knowledge_id_knowledge);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id_section);


--
-- Name: threads threads_pk; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.threads
    ADD CONSTRAINT threads_pk PRIMARY KEY (id_threads);


--
-- Name: user_course user_course_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.user_course
    ADD CONSTRAINT user_course_pkey PRIMARY KEY (course_id_course, user_uuid);


--
-- Name: user_quizzes user_quizzes_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.user_quizzes
    ADD CONSTRAINT user_quizzes_pkey PRIMARY KEY (id_user_quiz);


--
-- Name: user_role user_role_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_pkey PRIMARY KEY (role_id_role, user_uuid);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (uuid);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: knowledges_knowledge_title_index; Type: INDEX; Schema: public; Owner: fleetimee
--

CREATE INDEX knowledges_knowledge_title_index ON public.knowledges USING btree (knowledge_title);


--
-- Name: quizzes_id_quiz_quiz_title_index; Type: INDEX; Schema: public; Owner: fleetimee
--

CREATE INDEX quizzes_id_quiz_quiz_title_index ON public.quizzes USING btree (id_quiz, quiz_title);


--
-- Name: approval_course approval_course_courses_id_course_fk; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_course
    ADD CONSTRAINT approval_course_courses_id_course_fk FOREIGN KEY (id_course) REFERENCES public.courses(id_course);


--
-- Name: approval_course approval_course_users_uuid_fk; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_course
    ADD CONSTRAINT approval_course_users_uuid_fk FOREIGN KEY (user_uuid_approver) REFERENCES public.users(uuid);


--
-- Name: approval_course approval_course_users_uuid_fk2; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_course
    ADD CONSTRAINT approval_course_users_uuid_fk2 FOREIGN KEY (user_uuid_request) REFERENCES public.users(uuid);


--
-- Name: approval_knowledge approval_knowledge_knowledges_id_knowledge_fk; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_knowledge
    ADD CONSTRAINT approval_knowledge_knowledges_id_knowledge_fk FOREIGN KEY (id_knowledge) REFERENCES public.knowledges(id_knowledge) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: approval_knowledge approval_knowledge_users_uuid_fk; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_knowledge
    ADD CONSTRAINT approval_knowledge_users_uuid_fk FOREIGN KEY (user_uuid_approver) REFERENCES public.users(uuid);


--
-- Name: approval_knowledge approval_knowledge_users_uuid_fk2; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.approval_knowledge
    ADD CONSTRAINT approval_knowledge_users_uuid_fk2 FOREIGN KEY (user_uuid_request) REFERENCES public.users(uuid);


--
-- Name: knowledges fk_category_knowledge; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.knowledges
    ADD CONSTRAINT fk_category_knowledge FOREIGN KEY (id_category) REFERENCES public.category(id_category);


--
-- Name: courses fk_knowledges_course; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT fk_knowledges_course FOREIGN KEY (id_knowledge) REFERENCES public.knowledges(id_knowledge) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: answers fk_questions_answer; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.answers
    ADD CONSTRAINT fk_questions_answer FOREIGN KEY (id_question) REFERENCES public.questions(id_question) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: questions fk_quizzes_question; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT fk_quizzes_question FOREIGN KEY (id_quiz) REFERENCES public.quizzes(id_quiz) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_quizzes fk_quizzes_user_quiz; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.user_quizzes
    ADD CONSTRAINT fk_quizzes_user_quiz FOREIGN KEY (id_quiz) REFERENCES public.quizzes(id_quiz) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: section_course fk_section_course_course; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.section_course
    ADD CONSTRAINT fk_section_course_course FOREIGN KEY (course_id_course) REFERENCES public.courses(id_course) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: section_course fk_section_course_section; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.section_course
    ADD CONSTRAINT fk_section_course_section FOREIGN KEY (section_id_section) REFERENCES public.sections(id_section) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: section_knowledge fk_section_knowledge_knowledge; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.section_knowledge
    ADD CONSTRAINT fk_section_knowledge_knowledge FOREIGN KEY (knowledge_id_knowledge) REFERENCES public.knowledges(id_knowledge) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: section_knowledge fk_section_knowledge_section; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.section_knowledge
    ADD CONSTRAINT fk_section_knowledge_section FOREIGN KEY (section_id_section) REFERENCES public.sections(id_section) ON DELETE CASCADE;


--
-- Name: contents fk_sections_content; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.contents
    ADD CONSTRAINT fk_sections_content FOREIGN KEY (id_section) REFERENCES public.sections(id_section) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quizzes fk_sections_quiz; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT fk_sections_quiz FOREIGN KEY (id_section) REFERENCES public.sections(id_section) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_course fk_user_course_course; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.user_course
    ADD CONSTRAINT fk_user_course_course FOREIGN KEY (course_id_course) REFERENCES public.courses(id_course) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_course fk_user_course_user; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.user_course
    ADD CONSTRAINT fk_user_course_user FOREIGN KEY (user_uuid) REFERENCES public.users(uuid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_role fk_user_role_role; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT fk_user_role_role FOREIGN KEY (role_id_role) REFERENCES public.roles(id_role);


--
-- Name: user_role fk_user_role_user; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT fk_user_role_user FOREIGN KEY (user_uuid) REFERENCES public.users(uuid) ON DELETE CASCADE;


--
-- Name: user_quizzes fk_users_user_quiz; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.user_quizzes
    ADD CONSTRAINT fk_users_user_quiz FOREIGN KEY (user_uuid) REFERENCES public.users(uuid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: posts posts_threads_id_threads_fk; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_threads_id_threads_fk FOREIGN KEY (id_threads) REFERENCES public.threads(id_threads);


--
-- Name: posts posts_users_uuid_fk; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_users_uuid_fk FOREIGN KEY (user_uuid) REFERENCES public.users(uuid);


--
-- Name: threads threads_courses_id_course_fk; Type: FK CONSTRAINT; Schema: public; Owner: fleetimee
--

ALTER TABLE ONLY public.threads
    ADD CONSTRAINT threads_courses_id_course_fk FOREIGN KEY (id_course) REFERENCES public.courses(id_course);


--
-- PostgreSQL database dump complete
--

